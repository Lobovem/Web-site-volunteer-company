import s from './Breadcrumbs.module.scss';

export const Breadcrumbs = () => {
  return <div>TEST</div>;
};
