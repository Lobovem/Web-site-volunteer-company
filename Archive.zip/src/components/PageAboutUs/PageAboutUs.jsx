import s from './PageAboutUs.module.scss';

export const PageAboutUs = ({ children }) => {
  return <>{children}</>;
};
