import s from './PageHome.module.scss';

export const PageHome = ({ children }) => {
  return <>{children}</>;
};
